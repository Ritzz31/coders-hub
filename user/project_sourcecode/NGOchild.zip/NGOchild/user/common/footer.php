
      <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h2>About Us</h2>
                    <p>
                        Smart Eye is a leading provider of information technology, consulting, and business process services. Our dedicated employees offer strategic insights, technological expertise and industry experience.
                    </p>
                    <p>We focus on technologies that promise to reduce costs, streamline processes and speed time-to-market, Backed by our strong quality processes and rich experience managing global... </p>
                </div>
                <div class="col-md-6 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">
                        Child Adoption <br>
                        Marthandam (K.K District) <br>
                        Ahmedabad, IND <br>
                        Phone: +91 9159669599 <br>
                        Email: <a href="mailto:info@anybiz.com" class="">childadoption@ngo.in</a><br>
                        Web: <a href="smart-eye.html" class="">www.childadoption.in</a>
                    </address>

                </div>
            </div>
            
            

            </div>
            
        </div>
        

    </footer>
     <div class="copy">
            <div class="container">
                <a href="https://www.helpinghands.com/">2022 &copy; All Rights Reserved | by Child Adoption</a>
            </div>

     </div>
   